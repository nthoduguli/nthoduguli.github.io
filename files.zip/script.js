(function () {
  "use strict";

  var navLinks = document.querySelectorAll(".navlink");

  var sections = Array.prototype.map.call(navLinks, function (link) {
    var id = link.getAttribute("data-section");
    return { link: link, el: document.getElementById(id) };
  }).filter(function (s) { return s.el; });

  function setActive() {
    var scrollPos = window.scrollY + 140;
    var current = sections[0];

    sections.forEach(function (s) {
      if (s.el.offsetTop <= scrollPos) {
        current = s;
      }
    });

    sections.forEach(function (s) {
      s.link.classList.toggle("active", s === current);
    });
  }

  var ticking = false;
  window.addEventListener("scroll", function () {
    if (!ticking) {
      window.requestAnimationFrame(function () {
        setActive();
        ticking = false;
      });
      ticking = true;
    }
  });

  setActive();
})();
